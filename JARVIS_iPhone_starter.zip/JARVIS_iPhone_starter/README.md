# JARVIS – iPhone starter

Dette er første webapp-prototype til JARVIS.

## Indeholder
- Iron Man-inspireret mørkt/cyan design
- Privat- og firmatilstand
- Lokal notehukommelse i browseren
- Eksport og sletning af noter
- Stemmeinput via browserens SpeechRecognition, hvis understøttet
- PWA-filer til installation på iPhone-hjemmeskærmen efter HTTPS-hosting

## Vigtigt
Denne version har endnu IKKE en tilkoblet AI-model, Dinero-integration, adgang til SMS/iMessage/WhatsApp/Messenger eller automatisk beskedsending. Den er et fundament og gemmer noter lokalt i den browser/enhed, hvor den bruges.

## Sådan får du den på iPhone
Filerne skal først lægges på en HTTPS-webadresse (fx GitHub Pages). Når siden er offentliggjort:
1. Åbn webadressen i Safari på iPhone.
2. Tryk Del.
3. Vælg Føj til hjemmeskærm.
4. Åbn JARVIS fra ikonet.

Service worker/PWA-installation kræver HTTPS (eller localhost).
